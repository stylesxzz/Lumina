import {
  __clearRemoteImageCache,
  fetchModels,
  fetchModelsWithHeaders,
  testConnection,
  streamChatCompletion,
} from '../openai';
import type {StreamChatParams} from '../openai';
import type {RemoteEndpoint} from '../servers';
import {
  directTextModelsBody,
  directVisionModelsBody,
  routerModelsBody,
} from '../../../jest/fixtures/remoteModelList';
import {cacheReuseTimings} from '../../../jest/fixtures/llamaServerTimings';
import {runInAction} from 'mobx';
import {routerWireText} from '../../../jest/fixtures/routerWire';
import {isModelNotLoaded} from '../llamaServer/routerWire';

import {serverStore} from '../../store';

/**
 * The endpoint a streamed turn goes to. `serverType` is taken raw, because a
 * persisted value need not be a member of the union and these tests pin what
 * the free-string values reach.
 */
const endpointFor = (
  overrides: Partial<Omit<RemoteEndpoint, 'serverType'>> & {
    serverType?: string;
  } = {},
): RemoteEndpoint => ({
  url: 'http://localhost:1234',
  remoteModelId: 'test-model',
  serverType: 'unknown',
  ...(overrides as Partial<RemoteEndpoint>),
});

/** Build a minimal Headers-like object for fetch mocks. */
function mockHeaders(entries: Record<string, string> = {}) {
  const map = new Map(Object.entries(entries));
  return {
    forEach: (cb: (v: string, k: string) => void) =>
      map.forEach((v, k) => cb(v, k)),
  };
}

describe('fetchModels', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns model list from server', async () => {
    const mockModels = [
      {id: 'model-1', object: 'model', owned_by: 'system'},
      {id: 'model-2', object: 'model', owned_by: 'library'},
    ];

    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({data: mockModels}),
    });

    const result = await fetchModels('http://localhost:1234');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:1234/v1/models',
      expect.objectContaining({
        method: 'GET',
        headers: {'Content-Type': 'application/json'},
      }),
    );
    expect(result).toEqual(mockModels);
  });

  it('includes Authorization header when apiKey is provided', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({data: []}),
    });

    await fetchModels('http://localhost:1234', 'sk-test-key');

    expect(global.fetch).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer sk-test-key',
        },
      }),
    );
  });

  it('handles 401 unauthorized error', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
    });

    await expect(
      fetchModels('http://localhost:1234', 'bad-key'),
    ).rejects.toThrow('Unauthorized: Invalid or missing API key');
  });

  it('handles other server errors', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: false,
      status: 500,
      statusText: 'Internal Server Error',
    });

    await expect(fetchModels('http://localhost:1234')).rejects.toThrow(
      'Server error: 500 Internal Server Error',
    );
  });

  it('handles empty data field', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({}),
    });

    const result = await fetchModels('http://localhost:1234');
    expect(result).toEqual([]);
  });

  it('normalizes trailing slashes in server URL', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({data: []}),
    });

    await fetchModels('http://localhost:1234///');

    expect(global.fetch).toHaveBeenCalledWith(
      'http://localhost:1234/v1/models',
      expect.any(Object),
    );
  });

  // fetchModels forwards a supplied timeoutMs down to the underlying request:
  // a slow server that never answers aborts at the configured deadline.
  it('forwards timeoutMs to the underlying request (aborts at configured value)', async () => {
    jest.useFakeTimers();
    global.fetch = jest.fn().mockImplementation(
      (_url: string, opts: {signal: AbortSignal}) =>
        new Promise((_resolve, reject) => {
          opts.signal.addEventListener('abort', () => {
            const err = new Error('aborted');
            err.name = 'AbortError';
            reject(err);
          });
        }),
    );

    const promise = fetchModels('http://localhost:1234', undefined, 7000);
    jest.advanceTimersByTime(7000);
    await expect(promise).rejects.toThrow('Connection timed out');
    jest.useRealTimers();
  });
});

describe('fetchModelsWithHeaders', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns models and response headers', async () => {
    const mockModels = [{id: 'model-1', object: 'model', owned_by: 'system'}];

    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders({server: 'llama.cpp'}),
      json: () => Promise.resolve({data: mockModels}),
    });

    const result = await fetchModelsWithHeaders('http://localhost:8080');

    expect(result.models).toEqual(mockModels);
    expect(result.headers.server).toBe('llama.cpp');
  });

  // An undefined timeoutMs (e.g. a persisted ServerConfig from a prior version
  // with no requestTimeoutMs) is forwarded raw and must not crash; it behaves
  // identically to today (default applies).
  it('accepts an undefined timeoutMs without crashing', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({data: []}),
    });

    await expect(
      fetchModelsWithHeaders('http://localhost:8080', undefined, undefined),
    ).resolves.toEqual({models: [], headers: {}});
  });

  // The connection-phase guard on the models probe honours a supplied
  // timeoutMs: an unanswered request aborts at the configured deadline.
  it('aborts the models request at the configured timeout', async () => {
    jest.useFakeTimers();
    const abortSpy = jest.spyOn(AbortController.prototype, 'abort');
    // fetch never resolves — only the timeout can settle this.
    global.fetch = jest.fn().mockImplementation(
      (_url: string, opts: {signal: AbortSignal}) =>
        new Promise((_resolve, reject) => {
          opts.signal.addEventListener('abort', () => {
            const err = new Error('aborted');
            err.name = 'AbortError';
            reject(err);
          });
        }),
    );

    const promise = fetchModelsWithHeaders(
      'http://localhost:8080',
      undefined,
      5000,
    );
    jest.advanceTimersByTime(5000);
    await expect(promise).rejects.toThrow('Connection timed out');

    expect(abortSpy).toHaveBeenCalled();
    abortSpy.mockRestore();
    jest.useRealTimers();
  });

  describe('models[] capabilities', () => {
    const serve = (body: unknown) => {
      global.fetch = jest.fn().mockResolvedValueOnce({
        ok: true,
        headers: mockHeaders({server: 'llama.cpp'}),
        json: () => Promise.resolve(body),
      });
    };

    it('carries a direct server capabilities onto its data row', async () => {
      serve(directVisionModelsBody);

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models).toHaveLength(1);
      expect(models[0].id).toBe('gemma-4-e2b');
      expect(models[0].capabilities).toEqual(['completion', 'multimodal']);
      expect(models[0].meta?.n_ctx).toBe(8192);
    });

    it('distinguishes a text-only direct server by the same field', async () => {
      serve(directTextModelsBody);

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models[0].capabilities).toEqual(['completion']);
    });

    it('returns a router body untouched, models[] being absent there', async () => {
      serve(routerModelsBody);

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models).toEqual(routerModelsBody.data);
      expect(models.some(m => 'capabilities' in m)).toBe(false);
    });

    it('leaves rows alone when no entry names them', async () => {
      serve({
        data: [
          {id: 'a', object: 'model', owned_by: 'x'},
          {id: 'b', object: 'model', owned_by: 'x'},
        ],
        models: [{name: 'c', model: 'c', capabilities: ['completion']}],
      });

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models.some(m => 'capabilities' in m)).toBe(false);
    });

    it('pairs a lone row with a lone entry whatever the entry calls itself', async () => {
      serve({
        data: [{id: 'a', object: 'model', owned_by: 'x'}],
        models: [{name: 'something-else', capabilities: ['completion']}],
      });

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models[0].capabilities).toEqual(['completion']);
    });

    it('never pairs an id-less row with a nameless entry', async () => {
      serve({
        data: [
          {object: 'model', owned_by: 'x'},
          {id: 'b', object: 'model', owned_by: 'x'},
        ],
        models: [
          {capabilities: ['multimodal']},
          {name: 'other', capabilities: ['completion']},
        ],
      });

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models.some(m => 'capabilities' in m)).toBe(false);
    });

    it('ignores a models field that is not an array', async () => {
      serve({
        data: [{id: 'a', object: 'model', owned_by: 'x'}],
        models: {name: 'a', capabilities: ['completion']},
      });

      const {models} = await fetchModelsWithHeaders('http://localhost:8080');

      expect(models[0].capabilities).toBeUndefined();
    });
  });
});

describe('testConnection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns ok with model count on success', async () => {
    const mockModels = [
      {id: 'model-1', object: 'model', owned_by: 'system'},
      {id: 'model-2', object: 'model', owned_by: 'system'},
      {id: 'model-3', object: 'model', owned_by: 'system'},
    ];

    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () => Promise.resolve({data: mockModels}),
    });

    const result = await testConnection('http://localhost:1234');
    expect(result).toEqual({ok: true, modelCount: 3});
  });

  it('returns error on failure', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
    });

    const result = await testConnection('http://localhost:1234', 'bad-key');
    expect(result).toEqual({
      ok: false,
      modelCount: 0,
      error: 'Unauthorized: Invalid or missing API key',
    });
  });

  it('returns error on network failure', async () => {
    global.fetch = jest.fn().mockRejectedValueOnce(new Error('Network error'));

    const result = await testConnection('http://localhost:1234');
    expect(result).toEqual({
      ok: false,
      modelCount: 0,
      error: 'Network error',
    });
  });

  // testConnection forwards a supplied timeoutMs and reports the timeout as a
  // connection failure (rather than red-X-ing early) when the server is slow.
  it('forwards timeoutMs and reports a timeout as a failed probe', async () => {
    jest.useFakeTimers();
    global.fetch = jest.fn().mockImplementation(
      (_url: string, opts: {signal: AbortSignal}) =>
        new Promise((_resolve, reject) => {
          opts.signal.addEventListener('abort', () => {
            const err = new Error('aborted');
            err.name = 'AbortError';
            reject(err);
          });
        }),
    );

    const promise = testConnection('http://localhost:1234', undefined, 8000);
    jest.advanceTimersByTime(8000);

    await expect(promise).resolves.toEqual({
      ok: false,
      modelCount: 0,
      error: 'Connection timed out',
    });
    jest.useRealTimers();
  });

  // An undefined timeoutMs (old persisted config) is forwarded raw and the
  // probe still succeeds, identical to today.
  it('accepts an undefined timeoutMs without crashing', async () => {
    global.fetch = jest.fn().mockResolvedValueOnce({
      ok: true,
      headers: mockHeaders(),
      json: () =>
        Promise.resolve({data: [{id: 'm', object: 'model', owned_by: 'x'}]}),
    });

    await expect(
      testConnection('http://localhost:1234', undefined, undefined),
    ).resolves.toEqual({ok: true, modelCount: 1});
  });
});

// Mock XMLHttpRequest for streaming tests
type XHREventHandler = (() => void) | null;

class MockXHR {
  static instances: MockXHR[] = [];
  static HEADERS_RECEIVED = 2;
  static DONE = 4;

  method = '';
  url = '';
  requestHeaders: Record<string, string> = {};
  requestBody = '';
  responseText = '';
  readyState = 0;
  status = 0;
  statusText = '';

  onreadystatechange: XHREventHandler = null;
  onprogress: XHREventHandler = null;
  onload: XHREventHandler = null;
  onerror: XHREventHandler = null;
  onabort: XHREventHandler = null;

  constructor() {
    MockXHR.instances.push(this);
  }

  open(method: string, url: string) {
    this.method = method;
    this.url = url;
  }

  setRequestHeader(key: string, value: string) {
    this.requestHeaders[key] = value;
  }

  send(body?: string) {
    this.requestBody = body || '';
  }

  abort() {
    this.onabort?.();
  }

  // Simulate receiving headers
  simulateHeaders(status: number, statusText = 'OK') {
    this.readyState = 2; // HEADERS_RECEIVED
    this.status = status;
    this.statusText = statusText;
    this.onreadystatechange?.();
  }

  // Simulate a complete error response (headers + body + done)
  simulateErrorResponse(
    status: number,
    body: string | object,
    statusText = '',
  ) {
    this.readyState = 2;
    this.status = status;
    this.statusText = statusText;
    this.responseText = typeof body === 'string' ? body : JSON.stringify(body);
    this.onreadystatechange?.();
    this.readyState = 4;
    this.onreadystatechange?.();
  }

  // Simulate receiving a chunk of SSE data
  simulateProgress(text: string) {
    this.responseText += text;
    this.onprogress?.();
  }

  // Simulate request completion
  simulateLoad() {
    this.readyState = 4;
    this.onload?.();
  }

  // Simulate network error
  simulateError() {
    this.onerror?.();
  }
}

describe('streamChatCompletion', () => {
  let originalXHR: typeof XMLHttpRequest;

  beforeEach(() => {
    jest.clearAllMocks();
    __clearRemoteImageCache();
    MockXHR.instances = [];
    originalXHR = global.XMLHttpRequest;
    (global as any).XMLHttpRequest = MockXHR;
  });

  afterEach(() => {
    global.XMLHttpRequest = originalXHR;
  });

  it('streams tokens and returns full completion result', async () => {
    const onToken = jest.fn();
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
      undefined,
      onToken,
    );

    // Get the mock XHR instance
    const xhr = MockXHR.instances[0];

    // Simulate successful headers
    xhr.simulateHeaders(200);

    // Simulate SSE chunks arriving
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":" world"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');

    // Simulate completion
    xhr.simulateLoad();

    const result = await resultPromise;

    expect(result.text).toBe('Hello world');
    expect(result.content).toBe('Hello world');
    expect(result.stopped_eos).toBe(true);
    expect(result.tokens_predicted).toBe(2);

    expect(onToken).toHaveBeenCalledTimes(2);
    // content is accumulated (matching llama.rn behavior), token is delta
    expect(onToken).toHaveBeenCalledWith(
      expect.objectContaining({content: 'Hello', token: 'Hello'}),
    );
    expect(onToken).toHaveBeenCalledWith(
      expect.objectContaining({content: 'Hello world', token: ' world'}),
    );
  });

  it('sends correct request headers and body', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {temperature: 0.7, top_p: 0.9, n_predict: 100},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
        stop: ['</s>'],
      },
      endpointFor({apiKey: 'sk-key'}),
    );

    const xhr = MockXHR.instances[0];

    expect(xhr.method).toBe('POST');
    expect(xhr.url).toBe('http://localhost:1234/v1/chat/completions');
    expect(xhr.requestHeaders['Content-Type']).toBe('application/json');
    expect(xhr.requestHeaders.Authorization).toBe('Bearer sk-key');

    const body = JSON.parse(xhr.requestBody);
    expect(body.model).toBe('test-model');
    expect(body.temperature).toBe(0.7);
    expect(body.top_p).toBe(0.9);
    expect(body.max_completion_tokens).toBe(100);
    expect(body.stop).toEqual(['</s>']);
    expect(body.stream).toBe(true);

    // Complete the request
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    await resultPromise;
  });

  it('encodes a local image path to a data URI on the remote wire', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.readFile as jest.Mock).mockResolvedValueOnce('QUJD');

    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [
          {
            role: 'user',
            content: [
              {type: 'text', text: 'what is this?'},
              {type: 'image_url', image_url: {url: 'file:///tmp/photo.png'}},
            ],
          },
        ],
        model: 'test-model',
      },
      endpointFor(),
    );

    await new Promise(r => setImmediate(r));
    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.messages[0].content[1].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  it('passes through data: and http image urls unchanged', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');

    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'image_url',
                image_url: {url: 'data:image/jpeg;base64,ZZ'},
              },
              {type: 'image_url', image_url: {url: 'https://ex.com/a.png'}},
            ],
          },
        ],
        model: 'test-model',
      },
      endpointFor(),
    );

    await new Promise(r => setImmediate(r));
    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.messages[0].content[0].image_url.url).toBe(
      'data:image/jpeg;base64,ZZ',
    );
    expect(body.messages[0].content[1].image_url.url).toBe(
      'https://ex.com/a.png',
    );
    expect(RNFS.readFile).not.toHaveBeenCalled();

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  it('leaves a text-only message array untouched', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');

    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'plain text'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    await new Promise(r => setImmediate(r));
    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.messages[0].content).toBe('plain text');
    expect(RNFS.readFile).not.toHaveBeenCalled();

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  // Drive a stream to completion so its promise settles after the request
  // body has been inspected.
  const finishStream = async (
    xhr: MockXHR,
    resultPromise: Promise<unknown>,
  ) => {
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  };

  const imageMessage = (url: string) => ({
    role: 'user',
    content: [{type: 'image_url', image_url: {url}}],
  });

  it('encodes a local image once and re-uses the cache on the next send', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.readFile as jest.Mock).mockResolvedValue('QUJD');

    const p1 = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/cached.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body1 = JSON.parse(MockXHR.instances[0].requestBody);
    expect(body1.messages[0].content[0].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );
    await finishStream(MockXHR.instances[0], p1);

    const p2 = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/cached.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body2 = JSON.parse(MockXHR.instances[1].requestBody);
    expect(body2.messages[0].content[0].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );
    await finishStream(MockXHR.instances[1], p2);

    // The second send hit the cache — the file was read from disk only once.
    expect(RNFS.readFile).toHaveBeenCalledTimes(1);
  });

  it('evicts oldest-first once cached bytes exceed the 24MB budget', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    // ~9MB base64 per image; three exceed the 24MB cache budget, so caching the
    // third evicts the oldest (first) entry.
    const big = 'A'.repeat(9 * 1024 * 1024);
    (RNFS.readFile as jest.Mock).mockResolvedValue(big);

    const send = async (path: string) => {
      const p = streamChatCompletion(
        {samplers: {}, messages: [imageMessage(path)], model: 'm'},
        endpointFor(),
      );
      await new Promise(r => setImmediate(r));
      await finishStream(MockXHR.instances[MockXHR.instances.length - 1], p);
    };

    // Fill: A (oldest) → B → C. Caching C pushes bytes over budget and evicts A.
    await send('file:///tmp/a.png');
    await send('file:///tmp/b.png');
    await send('file:///tmp/c.png');
    expect(RNFS.readFile).toHaveBeenCalledTimes(3);

    // The two newest paths are still resident — re-sending them is a cache hit.
    await send('file:///tmp/c.png');
    await send('file:///tmp/b.png');
    expect(RNFS.readFile).toHaveBeenCalledTimes(3);

    // The oldest path was evicted, so re-sending it re-reads from disk.
    await send('file:///tmp/a.png');
    expect(RNFS.readFile).toHaveBeenCalledTimes(4);
  });

  it('dedups a concurrent double-encode of the same path (race-safe cache set)', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.readFile as jest.Mock).mockResolvedValue('QUJD');

    // Two sends of the same new path start before either populates the cache, so
    // both miss the read-side lookup and both call the cache setter; the second
    // set hits the `has()` guard and does not double-count the entry.
    const p1 = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/race.png')],
        model: 'm',
      },
      endpointFor(),
    );
    const p2 = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/race.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    await finishStream(MockXHR.instances[0], p1);
    await finishStream(MockXHR.instances[1], p2);
    expect(RNFS.readFile).toHaveBeenCalledTimes(2);

    // A subsequent send is a plain cache hit — the raced entry cached cleanly.
    const p3 = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/race.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    await finishStream(MockXHR.instances[2], p3);
    expect(RNFS.readFile).toHaveBeenCalledTimes(2);
  });

  it('maps a dotless path to image/jpeg (no invalid image// MIME)', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.readFile as jest.Mock).mockResolvedValueOnce('QUJD');

    const p = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('content://media/1234')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body = JSON.parse(MockXHR.instances[0].requestBody);
    expect(body.messages[0].content[0].image_url.url).toBe(
      'data:image/jpeg;base64,QUJD',
    );
    await finishStream(MockXHR.instances[0], p);
  });

  it('skips inlining a file whose successful stat exceeds the size cap', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.stat as jest.Mock).mockResolvedValueOnce({size: 20 * 1024 * 1024});

    const p = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/huge.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body = JSON.parse(MockXHR.instances[0].requestBody);
    // Left unchanged; the server surfaces the failure.
    expect(body.messages[0].content[0].image_url.url).toBe(
      'file:///tmp/huge.png',
    );
    expect(RNFS.readFile).not.toHaveBeenCalled();
    await finishStream(MockXHR.instances[0], p);
  });

  it('encodes anyway when stat is unavailable (undefined result)', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    // stat is an unconfigured jest.fn() → resolves undefined.
    (RNFS.readFile as jest.Mock).mockResolvedValueOnce('QUJD');

    const p = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/nostat.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body = JSON.parse(MockXHR.instances[0].requestBody);
    expect(body.messages[0].content[0].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );
    await finishStream(MockXHR.instances[0], p);
  });

  it('encodes anyway when stat rejects (healthy image not dropped)', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.stat as jest.Mock).mockRejectedValueOnce(new Error('stat failed'));
    (RNFS.readFile as jest.Mock).mockResolvedValueOnce('QUJD');

    const p = streamChatCompletion(
      {
        samplers: {},
        messages: [imageMessage('file:///tmp/statfail.png')],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body = JSON.parse(MockXHR.instances[0].requestBody);
    expect(body.messages[0].content[0].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );
    await finishStream(MockXHR.instances[0], p);
  });

  it('degrades per-image: a read failure leaves that part but encodes siblings', async () => {
    const RNFS = require('@dr.pogodin/react-native-fs');
    (RNFS.readFile as jest.Mock)
      .mockRejectedValueOnce(new Error('read failed'))
      .mockResolvedValueOnce('QUJD');

    const p = streamChatCompletion(
      {
        samplers: {},
        messages: [
          {
            role: 'user',
            content: [
              {type: 'image_url', image_url: {url: 'file:///tmp/bad.png'}},
              {type: 'image_url', image_url: {url: 'file:///tmp/ok.png'}},
            ],
          },
        ],
        model: 'm',
      },
      endpointFor(),
    );
    await new Promise(r => setImmediate(r));
    const body = JSON.parse(MockXHR.instances[0].requestBody);
    // The failed image is left unchanged; the sibling still encodes and the
    // completion promise does not reject.
    expect(body.messages[0].content[0].image_url.url).toBe(
      'file:///tmp/bad.png',
    );
    expect(body.messages[0].content[1].image_url.url).toBe(
      'data:image/png;base64,QUJD',
    );
    await finishStream(MockXHR.instances[0], p);
  });

  it('forwards response_format and injects json_schema.name for OpenAI compatibility', async () => {
    const schema = {type: 'object', properties: {name: {type: 'string'}}};
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
        response_format: {
          type: 'json_schema',
          json_schema: {strict: true, schema},
        },
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.response_format).toEqual({
      type: 'json_schema',
      json_schema: {strict: true, schema, name: 'response'},
    });

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  it('preserves caller-supplied json_schema.name', async () => {
    const schema = {type: 'object', properties: {x: {type: 'number'}}};
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
        response_format: {
          type: 'json_schema',
          json_schema: {name: 'custom', strict: false, schema},
        },
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.response_format.json_schema.name).toBe('custom');

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  it('maps finish_reason "length" to stopped_limit', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"text"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"length"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.stopped_limit).toBe(1);
    expect(result.stopped_eos).toBeUndefined();
  });

  it('maps finish_reason "content_filter" to interrupted', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"filtered"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"content_filter"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.interrupted).toBe(true);
  });

  it('skips malformed SSE events', async () => {
    const onToken = jest.fn();
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
      undefined,
      onToken,
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress('data: {"not_choices":"wrong structure"}\n\n');
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"valid"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.content).toBe('valid');
    expect(onToken).toHaveBeenCalledTimes(1);
  });

  it('handles reasoning_content in streaming delta', async () => {
    const onToken = jest.fn();
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
      undefined,
      onToken,
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"reasoning_content":"thinking..."},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"answer"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.reasoning_content).toBe('thinking...');
    expect(result.content).toBe('answer');
    expect(onToken).toHaveBeenCalledTimes(2);
    expect(onToken).toHaveBeenCalledWith(
      expect.objectContaining({reasoning_content: 'thinking...'}),
    );
  });

  it('handles delta.reasoning field (LM Studio format)', async () => {
    const onToken = jest.fn();
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
      undefined,
      onToken,
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"reasoning":"let me think..."},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"answer"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.reasoning_content).toBe('let me think...');
    expect(result.content).toBe('answer');
    expect(onToken).toHaveBeenCalledTimes(2);
    expect(onToken).toHaveBeenCalledWith(
      expect.objectContaining({reasoning_content: 'let me think...'}),
    );
  });

  it('rejects on 401 response', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateErrorResponse(401, {error: {message: 'Invalid API key'}});

    await expect(resultPromise).rejects.toThrow(
      'Unauthorized: Invalid or missing API key',
    );
  });

  it('rejects on network error', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateError();

    await expect(resultPromise).rejects.toThrow('Network error');
  });

  it('rejects on server error response with body', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateErrorResponse(500, {
      error: {message: 'Internal Server Error'},
    });

    await expect(resultPromise).rejects.toThrow(
      'Server error: 500 — Internal Server Error',
    );
  });

  it("reads a router's not-loaded refusal as such, from the captured body", async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    MockXHR.instances[0].simulateErrorResponse(
      400,
      routerWireText('completion-not-loaded-400.json'),
    );

    const error = await resultPromise.catch(e => e);
    expect(isModelNotLoaded(error)).toBe(true);
    expect(error.message).toBe('Server error: 400 — model is not loaded');
  });

  it('handles abort via AbortController', async () => {
    const controller = new AbortController();
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
      controller.signal,
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"partial"},"finish_reason":null}]}\n\n',
    );

    // Trigger abort
    controller.abort();

    const result = await resultPromise;
    expect(result.interrupted).toBe(true);
    expect(result.content).toBe('partial');
  });

  it('captures server-side timings from SSE events (llama.cpp)', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    // llama.cpp sends timings in the final event alongside finish_reason
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":{"predicted_per_token_ms":12.5,"predicted_per_second":80.0,"prompt_per_token_ms":1.2,"prompt_per_second":833.3}}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.timings).toEqual({
      predicted_per_token_ms: 12.5,
      predicted_per_second: 80.0,
      prompt_per_token_ms: 1.2,
      prompt_per_second: 833.3,
    });
    expect(result.content).toBe('Hello');
    expect(result.stopped_eos).toBe(true);
  });

  it('keeps the timings of the last event that carried them', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hi"},"finish_reason":null}],"timings":{"prompt_n":1,"predicted_n":1}}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":{"prompt_n":9,"predicted_n":4}}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.timings).toEqual({prompt_n: 9, predicted_n: 4});
    expect(result.tokens_evaluated).toBe(9);
    expect(result.tokens_predicted).toBe(4);
  });

  it('reads the final frame that arrives without a trailing blank line', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hel"},"finish_reason":null}]}\n\n',
    );
    // No terminating "\n\n", so the SSE parser holds this frame in its buffer
    // and only the flush at onload can reach it.
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"lo","reasoning_content":"why"},"finish_reason":"stop"}],"timings":{"prompt_n":7,"cache_n":2,"predicted_n":5}}',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.timings).toEqual({prompt_n: 7, cache_n: 2, predicted_n: 5});
    expect(result.tokens_evaluated).toBe(9);
    expect(result.tokens_predicted).toBe(5);
    expect(result.content).toBe('Hello');
    expect(result.reasoning_content).toBe('why');
    expect(result.stopped_eos).toBe(true);
  });

  it('reconciles token counts from timings prompt_n/predicted_n', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":{"prompt_n":3000,"predicted_n":500}}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    // Server counts win over the single content-bearing per-event tally.
    expect(result.tokens_evaluated).toBe(3000);
    expect(result.tokens_predicted).toBe(500);
  });

  it('adds the cache-reused prefix to the evaluated prompt count', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      `data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":${JSON.stringify(
        cacheReuseTimings,
      )}}\n\n`,
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    // The server evaluated one token and reused thirty-one, so reading
    // `prompt_n` alone reports 1 for a prompt of 32.
    expect(cacheReuseTimings.prompt_n).toBe(1);
    expect(result.tokens_evaluated).toBe(32);
    expect(result.tokens_predicted).toBe(3);
    // The total the context banner reads off the snapshot.
    expect(
      (result.tokens_evaluated ?? 0) + (result.tokens_predicted ?? 0),
    ).toBe(35);
  });

  // Both shapes are projected from the capture rather than retyped, so each
  // still carries the finish chunk's full nine-key `timings` object.
  it('distinguishes a reported cache_n of 0 from an absent one', async () => {
    const coldTimings = {...cacheReuseTimings, cache_n: 0};
    const preReuseTimings: Record<string, number> = {...cacheReuseTimings};
    delete preReuseTimings.cache_n;

    const finish = async (timings: Record<string, number>) => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor(),
      );
      const xhr = MockXHR.instances[MockXHR.instances.length - 1];
      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
      );
      xhr.simulateProgress(
        `data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":${JSON.stringify(
          timings,
        )}}\n\n`,
      );
      xhr.simulateProgress('data: [DONE]\n\n');
      xhr.simulateLoad();
      return resultPromise;
    };

    // A cold prompt on a build that reports reuse: 0 is a real count.
    const cold = await finish(coldTimings);
    expect(cold.tokens_evaluated).toBe(cacheReuseTimings.prompt_n);
    expect(cold.timings?.cache_n).toBe(0);

    // A build too old to report reuse omits the key. Same total, and the app
    // degrades to it rather than below it — but a different fact, and the
    // result keeps the two apart.
    const preReuse = await finish(preReuseTimings);
    expect(preReuse.tokens_evaluated).toBe(cacheReuseTimings.prompt_n);
    expect(preReuse.timings?.cache_n).toBeUndefined();
  });

  it('guards each timings token key independently (only predicted_n)', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":{"predicted_n":7}}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    // Missing prompt_n stays unset; predicted_n still wins.
    expect(result.tokens_evaluated).toBeUndefined();
    expect(result.tokens_predicted).toBe(7);
  });

  it('guards each timings token key independently (only prompt_n)', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":{"prompt_n":3000}}\n\n',
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    // prompt_n sets tokens_evaluated; absent predicted_n must NOT zero the
    // per-event tally — it keeps the single content-bearing event count.
    expect(result.tokens_evaluated).toBe(3000);
    expect(result.tokens_predicted).toBe(1);
    // A build too old to report prompt-cache reuse omits the key outright, and
    // must degrade to the prompt count it does report — never below it.
    expect(result.timings?.cache_n).toBeUndefined();
  });

  it('guards each timings token key independently (only cache_n)', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hello"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      `data: {"choices":[{"delta":{},"finish_reason":"stop"}],"timings":${JSON.stringify(
        {cache_n: cacheReuseTimings.cache_n},
      )}}\n\n`,
    );
    xhr.simulateProgress('data: [DONE]\n\n');
    xhr.simulateLoad();

    const result = await resultPromise;
    // A fully reused prompt evaluates nothing, so the whole count arrives on
    // cache_n and prompt_n is absent. Reading prompt_n alone loses it.
    expect(result.tokens_evaluated).toBe(31);
    expect(result.timings?.prompt_n).toBeUndefined();
  });

  it('returns no timings when server does not provide them', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'test-model',
      },
      endpointFor(),
    );

    const xhr = MockXHR.instances[0];
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{"content":"Hi"},"finish_reason":null}]}\n\n',
    );
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();

    const result = await resultPromise;
    expect(result.timings).toBeUndefined();
    // No timings → prompt count unset, predicted keeps the per-event tally.
    expect(result.tokens_evaluated).toBeUndefined();
    expect(result.tokens_predicted).toBe(1);
  });

  it('rejects immediately if signal already aborted', async () => {
    const controller = new AbortController();
    controller.abort();

    await expect(
      streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor(),
        controller.signal,
      ),
    ).rejects.toThrow('Completion aborted');
  });

  // PACT support over OpenAI-compatible remote engines.
  describe('tool support', () => {
    const calculateTool = {
      type: 'function' as const,
      function: {
        name: 'calculate',
        description: 'Evaluate a math expression',
        parameters: {
          type: 'object',
          properties: {expression: {type: 'string'}},
          required: ['expression'],
        },
      },
    };

    it('forwards tools and tool_choice in the request body', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'What is 2+2?'}],
          model: 'test-model',
          tools: [calculateTool],
          tool_choice: 'auto',
        },
        endpointFor(),
      );

      const xhr = MockXHR.instances[0];
      const body = JSON.parse(xhr.requestBody);
      expect(body.tools).toEqual([calculateTool]);
      expect(body.tool_choice).toBe('auto');

      // Drain so the promise resolves cleanly.
      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();
      await resultPromise;
    });

    it('omits tools/tool_choice from the body when caller did not supply them', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'hi'}],
          model: 'test-model',
        },
        endpointFor(),
      );
      const xhr = MockXHR.instances[0];
      const body = JSON.parse(xhr.requestBody);
      expect(body.tools).toBeUndefined();
      expect(body.tool_choice).toBeUndefined();

      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();
      await resultPromise;
    });

    it('omits empty tools array (some servers reject it)', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'hi'}],
          model: 'test-model',
          tools: [],
        },
        endpointFor(),
      );
      const xhr = MockXHR.instances[0];
      const body = JSON.parse(xhr.requestBody);
      expect(body.tools).toBeUndefined();

      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();
      await resultPromise;
    });

    it('reassembles streamed tool_call deltas into a single complete call', async () => {
      const onToken = jest.fn();
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'What is 2+2?'}],
          model: 'test-model',
          tools: [calculateTool],
        },
        endpointFor(),
        undefined,
        onToken,
      );

      const xhr = MockXHR.instances[0];
      xhr.simulateHeaders(200);

      // Chunk 1: id + name arrive on the first delta for index 0.
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_abc","type":"function","function":{"name":"calculate","arguments":""}}]},"finish_reason":null}]}\n\n',
      );
      // Chunk 2: arguments start streaming.
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"{\\"expression\\":\\"2"}}]},"finish_reason":null}]}\n\n',
      );
      // Chunk 3: arguments finish streaming.
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"+2\\"}"}}]},"finish_reason":null}]}\n\n',
      );
      // Final chunk: finish_reason="tool_calls".
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();

      const result = await resultPromise;

      // Final result carries the assembled call.
      expect(result.tool_calls).toEqual([
        {
          id: 'call_abc',
          type: 'function',
          function: {
            name: 'calculate',
            arguments: '{"expression":"2+2"}',
          },
        },
      ]);
      // tool_calls finish_reason maps to stopped_eos so the agent
      // loop treats it as a normal step end.
      expect(result.stopped_eos).toBe(true);

      // Per-chunk callbacks carry only THIS chunk's arguments fragment
      // (not the accumulated string); the assembled args live on the
      // final result.tool_calls. Keeps assembly out of the hot path.
      const toolCallEvents = onToken.mock.calls.filter(
        ([data]) => data.tool_calls && data.tool_calls.length > 0,
      );
      expect(toolCallEvents.length).toBe(3);
      const calls = toolCallEvents.map(c => c[0].tool_calls[0]);
      expect(calls[0]).toMatchObject({
        id: 'call_abc',
        function: {name: 'calculate', arguments: ''},
      });
      expect(calls[1]).toMatchObject({
        id: 'call_abc',
        function: {name: 'calculate', arguments: '{"expression":"2'},
      });
      expect(calls[2]).toMatchObject({
        id: 'call_abc',
        function: {name: 'calculate', arguments: '+2"}'},
      });
    });

    it('handles parallel tool_calls indexed across chunks', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
          tools: [calculateTool],
        },
        endpointFor(),
      );

      const xhr = MockXHR.instances[0];
      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_a","type":"function","function":{"name":"calculate","arguments":"{\\"x\\":1}"}},{"index":1,"id":"call_b","type":"function","function":{"name":"calculate","arguments":"{\\"x\\":2}"}}]},"finish_reason":null}]}\n\n',
      );
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();

      const result = await resultPromise;
      expect(result.tool_calls).toHaveLength(2);
      expect(result.tool_calls?.[0].id).toBe('call_a');
      expect(result.tool_calls?.[1].id).toBe('call_b');
    });
  });

  // Per-server configurable timeout: a single timeoutMs overrides BOTH the
  // connection-phase guard (default 30s) and the idle-between-chunks guard
  // (default 60s). The two-phase structure stays intact — only the durations
  // change. Driven with fake timers so we assert on the configured deadline.
  describe('configurable timeout', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.clearAllTimers();
      jest.useRealTimers();
    });

    // A raised connection timeout lets a slow cold-start server deliver
    // headers well past the 30s default without a premature reject.
    it('honours a raised connection timeout (does not abort before configured value)', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor({timeoutMs: 600000}),
      );
      // Surface any rejection deterministically without an unhandled promise.
      let rejected: Error | null = null;
      resultPromise.catch((e: Error) => {
        rejected = e;
      });

      const xhr = MockXHR.instances[0];

      // Past the 30s default, but well within the configured 600s window.
      jest.advanceTimersByTime(31000);
      await Promise.resolve();
      expect(rejected).toBeNull();
      expect(xhr.status).toBe(0); // never aborted yet

      // Headers finally arrive at ~200s — stream proceeds.
      jest.advanceTimersByTime(170000);
      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":null}]}\n\n',
      );
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();

      const result = await resultPromise;
      expect(result.content).toBe('ok');
      expect(rejected).toBeNull();
    });

    // With no timeoutMs supplied, the connection guard still fires at the
    // existing 30s default.
    it('aborts at the 30s default connection timeout when timeoutMs is omitted', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor(),
      );

      // Drive past the 30s default — no headers received.
      jest.advanceTimersByTime(30000);

      await expect(resultPromise).rejects.toThrow('Connection timed out');
    });

    // Once connected, an idle stall longer than the configured value aborts
    // via the idle guard (not the connection guard).
    it('aborts at the configured idle timeout after connecting', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor({timeoutMs: 120000}),
      );

      const xhr = MockXHR.instances[0];
      // Connect (clears the connection guard, arms the idle guard at 120s).
      xhr.simulateHeaders(200);
      xhr.simulateProgress(
        'data: {"choices":[{"delta":{"content":"first"},"finish_reason":null}]}\n\n',
      );

      // No further chunks for >120s → idle guard fires.
      jest.advanceTimersByTime(120000);

      await expect(resultPromise).rejects.toThrow(
        'Idle timeout: no data received',
      );
    });

    // The idle timer resets on each chunk; a healthy stream emitting within
    // the interval runs past the total wall-clock of the timeout. Only the
    // durations changed, not the per-chunk reset structure.
    it('resets the idle timer on each chunk (healthy stream outlives total timeout)', async () => {
      const resultPromise = streamChatCompletion(
        {
          samplers: {},
          messages: [{role: 'user', content: 'Hi'}],
          model: 'test-model',
        },
        endpointFor({timeoutMs: 100000}),
      );
      let rejected: Error | null = null;
      resultPromise.catch((e: Error) => {
        rejected = e;
      });

      const xhr = MockXHR.instances[0];
      xhr.simulateHeaders(200);

      // Emit a chunk every 80s (under the 100s idle window) five times —
      // total 400s, far beyond the 100s timeout, yet no idle abort because
      // each chunk resets the timer.
      for (let i = 0; i < 5; i++) {
        xhr.simulateProgress(
          `data: {"choices":[{"delta":{"content":"t${i}"},"finish_reason":null}]}\n\n`,
        );
        jest.advanceTimersByTime(80000);
        await Promise.resolve();
        expect(rejected).toBeNull();
      }

      xhr.simulateProgress(
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
      );
      xhr.simulateLoad();

      const result = await resultPromise;
      expect(result.content).toBe('t0t1t2t3t4');
      expect(rejected).toBeNull();
    });

    // Normalization happens exactly once inside openai.ts: a timeoutMs that is
    // undefined, NaN, non-finite, or <= 0 falls back to the default (here the
    // 30s connection guard); a positive finite value passes through. Asserted
    // via the observable connection-deadline behaviour.
    describe('normalization of invalid timeoutMs', () => {
      // For each invalid input, the connection guard must still fire at the
      // 30s default — i.e. the API never sets a 0/negative/NaN deadline.
      it.each([
        ['undefined', undefined],
        ['zero', 0],
        ['negative', -5000],
        ['NaN', NaN],
        ['Infinity', Infinity],
      ])(
        'falls back to the 30s default when timeoutMs is %s',
        async (_label, badValue) => {
          const resultPromise = streamChatCompletion(
            {
              samplers: {},
              messages: [{role: 'user', content: 'Hi'}],
              model: 'test-model',
            },
            endpointFor({timeoutMs: badValue as number | undefined}),
          );
          let rejected: Error | null = null;
          resultPromise.catch((e: Error) => {
            rejected = e;
          });

          // Just before the default deadline: still pending (not aborted at 0).
          jest.advanceTimersByTime(29000);
          await Promise.resolve();
          expect(rejected).toBeNull();

          // Crossing the 30s default fires the guard.
          jest.advanceTimersByTime(1000);
          await expect(resultPromise).rejects.toThrow('Connection timed out');
        },
      );

      // A positive finite value passes through untouched — the guard fires at
      // the configured value, not the default.
      it('passes a positive finite timeoutMs through (guard fires at configured value)', async () => {
        const resultPromise = streamChatCompletion(
          {
            samplers: {},
            messages: [{role: 'user', content: 'Hi'}],
            model: 'test-model',
          },
          endpointFor({timeoutMs: 5000}),
        );
        let rejected: Error | null = null;
        resultPromise.catch((e: Error) => {
          rejected = e;
        });

        // Before the configured 5s: pending.
        jest.advanceTimersByTime(4000);
        await Promise.resolve();
        expect(rejected).toBeNull();

        // At the configured 5s (well before the 30s default): aborts.
        jest.advanceTimersByTime(1000);
        await expect(resultPromise).rejects.toThrow('Connection timed out');
      });
    });
  });
});

describe('streamChatCompletion reasoning payload', () => {
  let originalXHR: typeof XMLHttpRequest;
  beforeEach(() => {
    originalXHR = global.XMLHttpRequest;
    (global as any).XMLHttpRequest = MockXHR;
    MockXHR.instances = [];
  });
  afterEach(() => {
    global.XMLHttpRequest = originalXHR;
  });

  it('attaches the gated payload by serverType', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'm',
        reasoning: {enabled: false},
      },
      endpointFor({serverType: 'llama.cpp'}),
    );
    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body.reasoning_format).toBe('auto');
    expect(body.chat_template_kwargs).toEqual({enable_thinking: false});
    // The internal carrier is never sent on the wire.
    expect(body).not.toHaveProperty('reasoning');

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });

  it('omits reasoning controls for an unknown serverType', async () => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'm',
        reasoning: {enabled: false, effort: 'high'},
      },
      endpointFor(),
    );
    const xhr = MockXHR.instances[0];
    const body = JSON.parse(xhr.requestBody);
    expect(body).not.toHaveProperty('reasoning_format');
    expect(body).not.toHaveProperty('chat_template_kwargs');
    expect(body).not.toHaveProperty('reasoning_effort');
    expect(body).not.toHaveProperty('think');

    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
  });
});

describe('streamChatCompletion sampler payload', () => {
  let originalXHR: typeof XMLHttpRequest;
  beforeEach(() => {
    originalXHR = global.XMLHttpRequest;
    (global as any).XMLHttpRequest = MockXHR;
    MockXHR.instances = [];
  });
  afterEach(() => {
    global.XMLHttpRequest = originalXHR;
  });

  /** Send one turn and return the parsed request body. */
  const bodyOf = async (
    params: Partial<StreamChatParams>,
    serverType?: string,
  ): Promise<any> => {
    const resultPromise = streamChatCompletion(
      {
        samplers: {},
        messages: [{role: 'user', content: 'Hi'}],
        model: 'm',
        ...params,
      },
      endpointFor({serverType}),
    );
    const xhr = MockXHR.instances[MockXHR.instances.length - 1];
    const body = JSON.parse(xhr.requestBody);
    xhr.simulateHeaders(200);
    xhr.simulateProgress(
      'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n',
    );
    xhr.simulateLoad();
    await resultPromise;
    return body;
  };

  it('carries the changed samplers alongside the unconditional fields', async () => {
    const body = await bodyOf(
      {
        samplers: {
          temperature: 0.7,
          top_p: 0.9,
          n_predict: 100,
          top_k: 10,
          penalty_repeat: 1.2,
        },
        stop: ['</s>'],
      },
      'llama.cpp',
    );

    expect(body.top_k).toBe(10);
    expect(body.repeat_penalty).toBe(1.2);
    expect(body.temperature).toBe(0.7);
    expect(body.top_p).toBe(0.9);
    expect(body.max_completion_tokens).toBe(100);
    expect(body.stop).toEqual(['</s>']);
    expect(body.stream).toBe(true);
  });

  it('omits a non-finite sampler handed straight to the transport', async () => {
    // `pickSamplers` drops non-finite values before the engine fills
    // `samplers`, so every other test reaches the transport with them already
    // gone. This caller bypasses it, which is what pins the transport-side
    // finite rule: without it the two filters mask each other and either can
    // be removed with nothing failing.
    const body = await bodyOf(
      {
        samplers: {
          temperature: NaN,
          top_p: Infinity,
          n_predict: -Infinity,
          top_k: 10,
        },
      },
      'llama.cpp',
    );

    expect(body).not.toHaveProperty('temperature');
    expect(body).not.toHaveProperty('top_p');
    expect(body).not.toHaveProperty('max_completion_tokens');
    expect(body.top_k).toBe(10);
  });

  it('sends an unknown server type the same body as before', async () => {
    const body = await bodyOf({
      samplers: {
        temperature: 0.7,
        top_p: 0.9,
        n_predict: 100,
        top_k: 10,
        penalty_repeat: 1.2,
      },
      stop: ['</s>'],
    });

    expect(body).toEqual({
      model: 'm',
      messages: [{role: 'user', content: 'Hi'}],
      stream: true,
      temperature: 0.7,
      top_p: 0.9,
      max_completion_tokens: 100,
      stop: ['</s>'],
    });
  });

  it('builds the same body whether or not a probe has landed', async () => {
    const params = {samplers: {top_k: 10, penalty_repeat: 1.2, seed: 7}};
    const before = await bodyOf(params, 'llama.cpp');

    runInAction(() => {
      serverStore.remoteCaps = {
        'srv/m': {
          samplerDefaults: {top_k: 40, penalty_repeat: 1.0, temperature: 0.8},
          probedUrl: 'http://localhost:1234',
        },
      };
    });

    const after = await bodyOf(params, 'llama.cpp');

    expect(after).toEqual(before);

    runInAction(() => {
      serverStore.remoteCaps = {};
    });
  });
});
