/**
 * E2E-only deep-link dispatcher. Only imported from a __E2E__-gated branch
 * in src/hooks/useDeepLinking.ts, so this module is DCE-stripped in prod.
 *
 * Supported protocols in v1:
 *   pocketpal://memory?cmd=snap::<label>
 *   pocketpal://memory?cmd=clear::snapshots
 *   pocketpal://tts?cmd=download::<engine>
 *   pocketpal://tts?cmd=synthesize::<engine>
 *   pocketpal://tts?cmd=release
 *   pocketpal://asr?cmd=state::<ready|not-installed|unsupported|recording|
 *                              transcribing|waiting-chat|error-capture|
 *                              error-blocked|error-memory|error-disk>
 *   pocketpal://voice?cmd=<verb>::<arg>   (voice mode, see voiceAutomation.ts)
 *   pocketpal://iap?cmd=<verb>::<arg>   (FakeStore script, see fakeStore.ts)
 *   pocketpal://e2e/plus-feature   (locked feature behind Plus; Android
 *                                   routes it in useDeepLinking.ts too)
 *   pocketpal://e2e/benchmark   (Android: cold-launch path lives in
 *                                useDeepLinking.ts since RN's Android side
 *                                doesn't deliver the URL via DeepLinkService)
 */
import type {DeepLinkParams} from '../services/DeepLinkService';
import {ROUTES} from '../utils/navigationConstants';
import {isBenchmarkRunnerUrl, parseBenchmarkAutostart} from './benchmarkRoute';
import {isPlusFeatureUrl} from './plusFeatureRoute';

interface NavigationLike {
  navigate: (route: string, params?: Record<string, unknown>) => void;
}

/** Returns true if handled; false if caller should fall through. */
export async function dispatchAutomationDeepLink(
  params: DeepLinkParams,
  navigation?: NavigationLike,
): Promise<boolean> {
  if (params.host === 'memory' && params.queryParams?.cmd) {
    const {
      takeMemorySnapshot,
      clearMemorySnapshots,
    } = require('../utils/memoryProfile');
    const cmd = params.queryParams.cmd;
    if (cmd.startsWith('snap::')) {
      const label = cmd.slice(6) || 'unnamed';
      await takeMemorySnapshot(label);
    } else if (cmd === 'clear::snapshots') {
      await clearMemorySnapshots();
    }
    return true;
  }
  if (params.host === 'tts' && params.queryParams?.cmd) {
    const {runTtsCommand} = require('./ttsAutomation');
    await runTtsCommand(params.queryParams.cmd);
    return true;
  }
  if (params.host === 'asr' && params.queryParams?.cmd) {
    const {runAsrCommand} = require('./asrAutomation');
    await runAsrCommand(params.queryParams.cmd);
    return true;
  }
  if (params.host === 'voice' && params.queryParams?.cmd) {
    const {runVoiceCommand} = require('./voiceAutomation');
    await runVoiceCommand(params.queryParams.cmd);
    return true;
  }
  if (params.host === 'iap' && params.queryParams?.cmd) {
    const {fakeStore} = require('./fakeStore');
    await fakeStore.run(params.queryParams.cmd);
    return true;
  }
  // pocketpal://e2e/benchmark — bench host. Match against the raw URL via
  // the shared helper so both deep-link sites (this dispatcher and the
  // useDeepLinking cold/warm-launch effect) accept the exact same shape.
  if (isBenchmarkRunnerUrl(params.url)) {
    // Resolve autostart from the same raw URL string via the shared helper —
    // NOT from params.queryParams — so the iOS/DeepLinkService origin and the
    // Android/Linking origin cannot diverge in truthiness.
    navigation?.navigate(ROUTES.BENCHMARK_RUNNER, {
      autostart: parseBenchmarkAutostart(params.url),
    });
    return true;
  }
  if (isPlusFeatureUrl(params.url)) {
    navigation?.navigate(ROUTES.PLUS_TEST_FEATURE);
    return true;
  }
  return false;
}
