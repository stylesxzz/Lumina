/**
 * Language Switching Test: Verifies all supported languages
 *
 * Cycles through each language and asserts the UI updates.
 * Does NOT require a model to be loaded.
 *
 * Usage:
 *   yarn test:ios:local --spec specs/language.spec.ts
 *   yarn test:android:local --spec specs/language.spec.ts
 */

import * as fs from 'fs';
import * as path from 'path';
import {ChatPage} from '../../pages/ChatPage';
import {DrawerPage} from '../../pages/DrawerPage';
import {SettingsPage} from '../../pages/SettingsPage';
import {byStaticText} from '../../helpers/selectors';
import {SCREENSHOT_DIR} from '../../wdio.shared.conf';

declare const driver: WebdriverIO.Browser;
declare const browser: WebdriverIO.Browser;

/**
 * Expected translated values for assertion.
 * Keys: screenTitles.settings (navigation header)
 * Values: settings.modelInitializationSettings (first card title)
 */
const LANGUAGE_ASSERTIONS: Record<
  string,
  {screenTitle: string; firstCardTitle: string}
> = {
  en: {
    screenTitle: 'Settings',
    firstCardTitle: 'Model Initialization Settings',
  },
  ar: {
    screenTitle: 'الإعدادات',
    firstCardTitle: 'إعدادات تهيئة النموذج',
  },
  es: {
    screenTitle: 'Ajustes',
    firstCardTitle: 'Ajustes de inicialización del modelo',
  },
  fa: {
    screenTitle: 'تنظیمات',
    firstCardTitle: 'تنظیمات راه‌اندازی مدل',
  },
  he: {
    screenTitle: 'הגדרות',
    firstCardTitle: 'הגדרות איתחול מודל',
  },
  id: {
    screenTitle: 'Pengaturan',
    firstCardTitle: 'Pengaturan Inisialisasi Model',
  },
  ja: {
    screenTitle: '設定',
    firstCardTitle: 'モデル初期化設定',
  },
  ko: {
    screenTitle: '설정',
    firstCardTitle: '모델 초기화 설정',
  },
  ms: {
    screenTitle: 'Tetapan',
    firstCardTitle: 'Tetapan Permulaan Model',
  },
  pl: {
    screenTitle: 'Ustawienia',
    firstCardTitle: 'Ustawienia Inicjalizacji Modelu',
  },
  // pt shares both of these strings with pt_BR, so this spec proves the switch
  // works but not that the two locales are distinct — locales.test.ts covers that.
  pt: {
    screenTitle: 'Configurações',
    firstCardTitle: 'Configurações de Inicialização do Modelo',
  },
  pt_BR: {
    screenTitle: 'Configurações',
    firstCardTitle: 'Configurações de Inicialização do Modelo',
  },
  ru: {
    screenTitle: 'Настройки',
    firstCardTitle: 'Настройки инициализации модели',
  },
  uk: {
    screenTitle: 'Налаштування',
    firstCardTitle: 'Налаштування ініціалізації моделі',
  },
  zh: {
    screenTitle: '设置',
    firstCardTitle: '模型初始化设置',
  },
  zh_Hant: {
    screenTitle: '設定',
    firstCardTitle: '模型初始化設定',
  },
};

// Order: start with non-English, end with English to restore default state
const LANGUAGE_ORDER = ['ar', 'es', 'fa', 'he', 'id', 'ja', 'ko', 'ms', 'pl', 'pt', 'pt_BR', 'ru', 'uk', 'zh', 'zh_Hant', 'en'];

describe('Language Switching', () => {
  let chatPage: ChatPage;
  let drawerPage: DrawerPage;
  let settingsPage: SettingsPage;

  beforeEach(async () => {
    chatPage = new ChatPage();
    drawerPage = new DrawerPage();
    settingsPage = new SettingsPage();

    await chatPage.waitForReady(30000);
  });

  afterEach(async function (this: Mocha.Context) {
    if (this.currentTest?.state === 'failed') {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const testName = this.currentTest.title.replace(/\s+/g, '-');
      try {
        if (!fs.existsSync(SCREENSHOT_DIR)) {
          fs.mkdirSync(SCREENSHOT_DIR, {recursive: true});
        }
        await driver.saveScreenshot(
          path.join(SCREENSHOT_DIR, `failure-${testName}-${timestamp}.png`),
        );
      } catch (e) {
        console.error('Failed to capture screenshot:', (e as Error).message);
      }
    }
  });

  it('should switch between all supported languages', async () => {
    // Navigate: Chat -> Drawer -> Settings
    await chatPage.openDrawer();
    await drawerPage.waitForOpen();
    await drawerPage.navigateToSettings();
    await settingsPage.waitForReady();

    // Ensure screenshot directory exists
    if (!fs.existsSync(SCREENSHOT_DIR)) {
      fs.mkdirSync(SCREENSHOT_DIR, {recursive: true});
    }

    // Cycle through each language
    for (const lang of LANGUAGE_ORDER) {
      console.log(`\n--- Switching to: ${lang} ---`);
      const expected = LANGUAGE_ASSERTIONS[lang];

      // Scroll to the language selector
      const found = await settingsPage.scrollToLanguageSelector();
      if (!found) {
        throw new Error(
          `Could not find language selector button after scrolling`,
        );
      }

      // Open language menu and select the language
      await settingsPage.openLanguageMenu();
      await settingsPage.selectLanguage(lang);

      // After language change, screen re-renders and scrolls to top.
      // Assert the navigation header title changed.
      // Use byStaticText to target text elements only (excludes buttons).
      // On iOS this avoids matching hidden drawer buttons.
      // On Android this matches both TextView and View (React Navigation header).
      const titleElement = browser.$(byStaticText(expected.screenTitle));
      await titleElement.waitForDisplayed({timeout: 5000});
      console.log(`  Screen title: "${expected.screenTitle}" - OK`);

      // Assert the first card title changed (visible at top after re-render).
      const cardTitleElement = browser.$(byStaticText(expected.firstCardTitle));
      await cardTitleElement.waitForDisplayed({timeout: 5000});
      console.log(`  First card title: "${expected.firstCardTitle}" - OK`);

      // Take screenshot
      await driver.saveScreenshot(
        path.join(SCREENSHOT_DIR, `language-${lang}.png`),
      );
      console.log(`  Screenshot saved: language-${lang}.png`);
    }

    console.log('\n=== Language switching test complete ===');
  });
});
