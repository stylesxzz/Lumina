import {sessionFixtures} from '../../jest/fixtures/chatSessions';
import type {
  BannerVariant,
  CompletionResultSnapshot,
} from '../../src/utils/completionTypes';

// Mock defaultCompletionSettings to avoid circular imports
// This should match the actual defaultCompletionSettings from ChatSessionStore
export const mockDefaultCompletionSettings = {
  version: 3,
  include_thinking_in_context: true,
  n_predict: 1024,
  temperature: 0.7,
  top_k: 40,
  top_p: 0.95,
  min_p: 0.05,
  xtc_threshold: 0.1,
  xtc_probability: 0.0,
  typical_p: 1.0,
  penalty_last_n: 64,
  penalty_repeat: 1.0,
  penalty_freq: 0.0,
  penalty_present: 0.0,
  mirostat: 0,
  mirostat_tau: 5,
  mirostat_eta: 0.1,
  seed: -1,
  n_probs: 0,
  jinja: true,
  enable_thinking: true,
};

export const mockChatSessionStore = {
  sessions: sessionFixtures,
  //currentSessionMessages: [],
  activeSessionId: 'session-1',
  newChatCompletionSettings: mockDefaultCompletionSettings,
  newChatThinkingOverride: undefined as boolean | undefined,
  newChatReasoningEffort: undefined as string | undefined,
  isMigrating: false,
  migrationComplete: true,
  // Draft autosave
  sessionDrafts: new Map<string, string>(),
  saveDraft: jest.fn(),
  getDraft: jest.fn().mockReturnValue(''),
  clearDraft: jest.fn(),
  restoreUnsentText: jest.fn(),
  // Selection mode state
  isSelectionMode: false,
  selectedSessionIds: new Set<string>(),
  loadSessionList: jest.fn().mockResolvedValue(undefined),
  loadGlobalSettings: jest.fn().mockResolvedValue(undefined),
  deleteSession: jest.fn().mockResolvedValue(undefined),
  setActiveSession: jest.fn().mockResolvedValue(undefined),
  addMessageToCurrentSession: jest.fn().mockResolvedValue(undefined),
  addMessageToSession: jest.fn().mockResolvedValue(undefined),
  deleteMessageFromSession: jest.fn().mockResolvedValue(undefined),
  resetActiveSession: jest.fn(),
  updateSessionTitle: jest.fn().mockResolvedValue(undefined),
  updateSessionTitleBySessionId: jest.fn().mockResolvedValue(undefined),
  groupedSessions: {
    Today: [sessionFixtures[0]],
    Yesterday: [sessionFixtures[1]],
  },
  createNewSession: jest.fn().mockResolvedValue(undefined),
  updateMessage: jest.fn().mockResolvedValue(undefined),
  updateMessageStreaming: jest.fn().mockResolvedValue(undefined),
  updateSessionCompletionSettings: jest.fn().mockResolvedValue(undefined),
  applySessionSettingsToGlobal: jest.fn().mockResolvedValue(undefined),
  resetSessionSettingsToGlobal: jest.fn().mockResolvedValue(undefined),
  exitEditMode: jest.fn(),
  enterEditMode: jest.fn(),
  removeMessagesFromId: jest.fn(),
  setIsGenerating: jest.fn(),
  setIsStopping: jest.fn(),
  isStopping: false,
  duplicateSession: jest.fn().mockResolvedValue(undefined),
  setNewChatCompletionSettings: jest.fn().mockResolvedValue(undefined),
  resetNewChatCompletionSettings: jest.fn().mockResolvedValue(undefined),
  setActivePal: jest.fn().mockResolvedValue(undefined),
  resolveCompletionSettings: jest
    .fn()
    .mockResolvedValue(mockDefaultCompletionSettings),
  getCurrentCompletionSettings: jest
    .fn()
    .mockResolvedValue(mockDefaultCompletionSettings),
  // Selection mode methods
  enterSelectionMode: jest.fn(),
  exitSelectionMode: jest.fn(),
  toggleSessionSelection: jest.fn(),
  selectAllSessions: jest.fn(),
  deselectAllSessions: jest.fn(),
  bulkDeleteSessions: jest.fn().mockResolvedValue(undefined),
  bulkExportSessions: jest.fn().mockResolvedValue(undefined),
  togglePinSession: jest.fn().mockResolvedValue(undefined),
  dateGroupNames: {
    pinned: 'Pinned',
    today: 'Today',
    yesterday: 'Yesterday',
    thisWeek: 'This week',
    lastWeek: 'Last week',
    twoWeeksAgo: '2 weeks ago',
    threeWeeksAgo: '3 weeks ago',
    fourWeeksAgo: '4 weeks ago',
    lastMonth: 'Last month',
    older: 'Older',
  },
  setDateGroupNames: jest.fn(),
  initialize: jest.fn().mockResolvedValue(undefined),
  // Agent UI state and per-step actions (added with AssistantTurn refactor)
  agentUiState: {
    status: 'idle' as
      | 'idle'
      | 'prefill'
      | 'streaming_text'
      | 'generating_tool_call'
      | 'executing_tool'
      | 'done'
      | 'failed',
    pendingTalentNames: [] as string[],
    hitMaxTurns: false,
  },
  setAgentUiState: jest.fn(),
  toolCallTokenCount: 0,
  setToolCallTokenCount: jest.fn(),
  pushAgentStep: jest.fn().mockResolvedValue(undefined),
  updateActiveStepStreaming: jest.fn(),
  appendToolCall: jest.fn().mockResolvedValue(undefined),
  appendToolOutcome: jest.fn().mockResolvedValue(undefined),
  finalizeActiveStep: jest.fn().mockResolvedValue(undefined),
  // Context-limit banner state
  lastCompletionResult: undefined as CompletionResultSnapshot | undefined,
  dismissedBannerVariants: new Set<BannerVariant>(),
  consecutiveFullFailures: 0,
  palLoadHintSeen: new Set<string>(),
  recordCompletionSnapshot: jest.fn(),
  setBannerDismissed: jest.fn(),
  markPalLoadHintSeen: jest.fn(),
};

Object.defineProperty(mockChatSessionStore, 'isGeneratingToolCall', {
  get: jest.fn(
    () => mockChatSessionStore.agentUiState.status === 'generating_tool_call',
  ),
  configurable: true,
});

Object.defineProperty(mockChatSessionStore, 'currentSessionMessages', {
  get: jest.fn(() => []),
  configurable: true,
});

Object.defineProperty(mockChatSessionStore, 'activePalId', {
  get: jest.fn(() => null),
  configurable: true,
});

Object.defineProperty(mockChatSessionStore, 'shouldShowHeaderDivider', {
  get: jest.fn(() => true),
  configurable: true,
});

Object.defineProperty(mockChatSessionStore, 'selectedCount', {
  get: jest.fn(() => mockChatSessionStore.selectedSessionIds.size),
  configurable: true,
});

Object.defineProperty(mockChatSessionStore, 'allSelected', {
  get: jest.fn(
    () =>
      mockChatSessionStore.sessions.length > 0 &&
      mockChatSessionStore.selectedSessionIds.size ===
        mockChatSessionStore.sessions.length,
  ),
  configurable: true,
});
