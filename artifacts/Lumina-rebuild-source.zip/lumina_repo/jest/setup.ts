import 'react-native-gesture-handler/jestSetup';
import mockClipboard from '@react-native-clipboard/clipboard/jest/clipboard-mock.js';

import 'react-native-gesture-handler/jestSetup';

// __E2E__ is a build-time constant in prod/e2e builds (see babel.config.js),
// but in Jest the transform-define plugin is disabled so it stays a runtime
// global. Default to true so adapter tests render their components; tests
// that assert the DCE gate override with `(global as any).__E2E__ = false`.
(global as any).__E2E__ = true;
// Onboarding bypass flag: default off in Jest so the AutomationBridge
// adapter renders but no-ops; tests that need the bypass-on path override
// with `(global as any).__E2E_SKIP_ONBOARDING__ = true`.
(global as any).__E2E_SKIP_ONBOARDING__ = false;

jest.mock('react-native-haptic-feedback');

jest.mock('react-native-keyboard-controller', () => {
  const KeyboardControllerMock = require('react-native-keyboard-controller/jest');
  return KeyboardControllerMock;
});

// Mock react-native-reanimated
//require('react-native-reanimated').setUpTests();
jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');

  Reanimated.default.call = () => {};

  Reanimated.useReducedMotion = jest.fn(() => false);

  Reanimated.useSharedValue = jest.fn(() => ({value: 0}));
  Reanimated.useAnimatedStyle = jest.fn(() => ({}));
  Reanimated.useAnimatedScrollHandler = jest.fn(() => ({}));
  Reanimated.useAnimatedProps = jest.fn(() => ({}));
  Reanimated.useAnimatedGestureHandler = jest.fn(() => ({}));
  Reanimated.withTiming = jest.fn(() => ({}));
  Reanimated.withSpring = jest.fn(() => ({}));
  Reanimated.cancelAnimation = jest.fn();

  Reanimated.default.createAnimatedComponent = (Component: any) => Component;

  return Reanimated;
});

jest.mock('@react-navigation/elements', () => ({
  ...jest.requireActual('@react-navigation/elements'),
  useHeaderHeight: jest.fn().mockReturnValue(56), // Provide a mock return value
}));

import {mockUiStore} from '../__mocks__/stores/uiStore';
import {mockHFStore} from '../__mocks__/stores/hfStore';
import {mockModelStore} from '../__mocks__/stores/modelStore';
import {
  mockChatSessionStore,
  mockDefaultCompletionSettings,
} from '../__mocks__/stores/chatSessionStore';
import {benchmarkStore as mockBenchmarkStore} from '../__mocks__/stores/benchmarkStore';
import {mockPalStore} from '../__mocks__/stores/palStore';
import {deepLinkStore as mockDeepLinkStore} from '../__mocks__/stores/deepLinkStore';
import {mockServerStore} from '../__mocks__/stores/serverStore';
import {mockRouterStore} from '../__mocks__/stores/routerStore';
import {mockTTSStore} from '../__mocks__/stores/ttsStore';
import {mockASRStore} from '../__mocks__/stores/asrStore';
import {
  mockVoiceEntitlement,
  mockVoiceModeStore,
} from '../__mocks__/stores/voiceModeStore';
import {mockSearchProviderStore} from '../__mocks__/stores/searchProviderStore';
import {mockPurchaseStore} from '../__mocks__/stores/purchaseStore';

jest.mock('@react-native-clipboard/clipboard', () => mockClipboard);

jest.mock('react-native/Libraries/EventEmitter/NativeEventEmitter');

// The automocked emitter hands back no subscription, so a component that
// removes its Keyboard listener on unmount would throw.
require('react-native').Keyboard.addListener = () => ({remove: () => {}});

jest.mock('../src/specs/NativeNavigationBar', () => ({
  __esModule: true,
  default: {setNavigationBarDark: jest.fn()},
}));

// Mock NativeHardwareInfo TurboModule
jest.mock('../src/specs/NativeHardwareInfo', () => ({
  __esModule: true,
  default: {
    getCPUInfo: jest.fn(() => Promise.resolve({cores: 4})),
    getGPUInfo: jest.fn(() =>
      Promise.resolve({
        renderer: 'Mock GPU',
        vendor: 'Mock Vendor',
        version: 'Mock Version',
        hasAdreno: false,
        hasMali: false,
        hasPowerVR: false,
        supportsOpenCL: false,
        gpuType: 'Mock GPU',
      }),
    ),
    getChipset: jest.fn(() => Promise.resolve('Mock Chipset')),
    getAvailableMemory: jest.fn(() => Promise.resolve(3 * 1000 * 1000 * 1000)), // 3GB
    writeMemorySnapshot: jest.fn((label: string) =>
      Promise.resolve({label, status: 'written'}),
    ),
    purgeNativeAllocator: jest.fn(() =>
      Promise.resolve({purged: true, rss_kb_before: 0, rss_kb_after: 0}),
    ),
  },
}));

jest.mock('react-native-safe-area-context', () => {
  const inset = {top: 0, right: 0, bottom: 0, left: 0};
  return {
    ...jest.requireActual('react-native-safe-area-context'),
    SafeAreaProvider: jest.fn(({children}) => children),
    SafeAreaConsumer: jest.fn(({children}) => children(inset)),
    useSafeAreaInsets: jest.fn(() => inset),
    useSafeAreaFrame: jest.fn(() => ({x: 0, y: 0, width: 390, height: 844})),
  };
});

jest.mock('../src/store', () => {
  const {UIStore} = require('../__mocks__/stores/uiStore');
  return {
    modelStore: mockModelStore,
    UIStore,
    uiStore: mockUiStore,
    chatSessionStore: mockChatSessionStore,
    NEW_CHAT_DRAFT_KEY: '__new_chat__',
    hfStore: mockHFStore,
    benchmarkStore: mockBenchmarkStore,
    palStore: mockPalStore,
    deepLinkStore: mockDeepLinkStore,
    serverStore: mockServerStore,
    routerStore: mockRouterStore,
    ttsStore: mockTTSStore,
    asrStore: mockASRStore,
    voiceModeStore: mockVoiceModeStore,
    voiceEntitlement: mockVoiceEntitlement,
    searchProviderStore: mockSearchProviderStore,
    purchaseStore: mockPurchaseStore,
    defaultCompletionSettings: mockDefaultCompletionSettings,
    NEW_SESSION_TITLE: 'New Session',
  };
});

jest.mock('../src/hooks/useTheme', () => {
  const {themeFixtures} = require('./fixtures/theme');
  return {
    useTheme: jest.fn().mockReturnValue(themeFixtures.lightTheme),
  };
});

jest.mock('../src/hooks/useMemoryCheck', () => ({
  useMemoryCheck: jest.fn().mockReturnValue({
    memoryWarning: '',
    shortMemoryWarning: '',
    multimodalWarning: '',
  }),
  hasEnoughMemory: jest.fn().mockResolvedValue(true),
  isHighEndDevice: jest.fn().mockResolvedValue(true),
}));

jest.mock('../src/services/downloads', () => ({
  downloadManager: require('../__mocks__/services/downloads').downloadManager,
}));

jest.mock('uuid', () => ({
  v4: () => 'mock-uuid-12345' + Math.random(),
}));

jest.mock('../src/repositories/ChatSessionRepository', () => ({
  chatSessionRepository:
    require('../__mocks__/repositories/ChatSessionRepository')
      .chatSessionRepository,
}));

jest.mock('react-native-worklets', () =>
  require('react-native-worklets/lib/module/mock'),
);

// React Native provides requestIdleCallback; Jest's environment doesn't.
(global as any).requestIdleCallback = (callback: () => void) => callback();

jest.mock('../src/utils/keepAwake', () => ({
  acquireKeepAwake: jest.fn(() => jest.fn()),
}));

jest.mock('react-native-share', () => ({
  default: jest.fn(),
}));

jest.mock('react-native-image-picker');
jest.mock('react-native-vision-camera');

jest.mock('../src/database', () => {
  return {
    database: require('../__mocks__/database').mockDatabase,
  };
});

jest.mock('../src/services', () => {
  return require('../__mocks__/services');
});

jest.mock('../src/services/palshub/accountDeletion', () =>
  require('../__mocks__/services/palshub/accountDeletion'),
);
